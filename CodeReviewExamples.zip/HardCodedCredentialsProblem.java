// Detect hard-coded credentials.

public class HardCodedCredentialsProblem {
    public void authenticate() {
        String username = "admin";
        String password = "password";
        System.out.println("Authenticating with " + username + "/" + password);
    }
}
