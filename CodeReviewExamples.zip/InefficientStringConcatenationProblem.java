// Detect inefficient string concatenation in loops.

public class InefficientStringConcatenationProblem {
    public void concatenateStrings(String[] strings) {
        String result = "";
        for (String str : strings) {
            result += str;
        }
        System.out.println(result);
    }
}
