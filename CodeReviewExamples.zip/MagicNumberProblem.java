// Detect usage of magic numbers.

public class MagicNumberProblem {
    public void process() {
        int maxRetries = 5;
        for (int i = 0; i < maxRetries; i++) {
            System.out.println("Retry " + i);
        }
    }
}
