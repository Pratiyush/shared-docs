// Detect improper method overloading.

public class OverloadedMethodProblem {
    public void print(int number) {
        System.out.println("Number: " + number);
    }

    public void print(String number) {
        System.out.println("Number: " + number);
    }
}
