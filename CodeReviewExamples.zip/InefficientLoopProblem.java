// Detect inefficient loop.

public class InefficientLoopProblem {
    public void process(int[] numbers) {
        for (int i = 0; i < numbers.length; i++) {
            for (int j = 0; j < numbers.length; j++) {
                System.out.println(numbers[i] + numbers[j]);
            }
        }
    }
}
