// Detect improper synchronization.

public class ImproperSynchronizationProblem {
    private int counter = 0;

    public void increment() {
        new Thread(() -> counter++).start();
        new Thread(() -> counter++).start();
    }
}
