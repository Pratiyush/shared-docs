// Detect potential null pointer exception.

public class NullPointerExceptionProblem {
    public void printLength(String str) {
        System.out.println(str.length());
    }
}
