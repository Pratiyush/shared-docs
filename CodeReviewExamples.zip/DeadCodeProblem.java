// Detect dead code.

public class DeadCodeProblem {
    public void process() {
        int value = 10;
        if (false) {
            value++;
        }
        System.out.println("Value: " + value);
    }
}
