// Detect hard-coded file path.

import java.io.File;

public class HardCodedPathProblem {
    public void createFile() {
        File file = new File("/home/user/file.txt");
        System.out.println(file.exists());
    }
}
