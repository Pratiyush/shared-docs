// Detect redundant null check.

public class RedundantNullCheckProblem {
    public void checkString(String str) {
        if (str != null) {
            if (str.length() > 0) {
                System.out.println("String is not empty");
            }
        }
    }
}
