// Detect unused variable.

public class UnusedVariableProblem {
    public void process() {
        int unused = 10;
        System.out.println("Processing...");
    }
}
