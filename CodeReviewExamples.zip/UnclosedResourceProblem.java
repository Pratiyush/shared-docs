// Detect unclosed resource.

import java.io.FileWriter;
import java.io.IOException;

public class UnclosedResourceProblem {
    public void writeFile(String content) throws IOException {
        FileWriter writer = new FileWriter("output.txt");
        writer.write(content);
    }
}
