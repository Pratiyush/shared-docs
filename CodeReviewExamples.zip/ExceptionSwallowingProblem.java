// Detect exception swallowing.

public class ExceptionSwallowingProblem {
    public void divide(int a, int b) {
        try {
            int result = a / b;
            System.out.println("Result: " + result);
        } catch (Exception e) {
            // Exception swallowed
        }
    }
}
