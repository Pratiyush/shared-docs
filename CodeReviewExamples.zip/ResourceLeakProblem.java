// Detect resource leak.

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ResourceLeakProblem {
    public void readFile(String fileName) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        System.out.println(reader.readLine());
    }
}
