// Detect usage of insecure random generator.

import java.util.Random;

public class InsecureRandomProblem {
    public void generateRandomNumber() {
        Random random = new Random();
        System.out.println(random.nextInt());
    }
}
