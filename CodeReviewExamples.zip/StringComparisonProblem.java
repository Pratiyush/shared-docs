// Detect improper string comparison.

public class StringComparisonProblem {
    public void compareStrings(String str1, String str2) {
        if (str1 == str2) {
            System.out.println("Strings are the same");
        }
    }
}
