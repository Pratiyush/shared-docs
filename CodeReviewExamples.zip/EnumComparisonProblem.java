// Detect improper enum comparison.

public class EnumComparisonProblem {
    enum Color {
        RED, GREEN, BLUE
    }

    public void compareColors(Color color1, Color color2) {
        if (color1.equals(color2)) {
            System.out.println("Colors are the same");
        }
    }
}
