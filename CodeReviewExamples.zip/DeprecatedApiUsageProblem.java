// Detect usage of deprecated API.

public class DeprecatedApiUsageProblem {
    public void stopThread() {
        Thread thread = new Thread();
        thread.stop();
    }
}
