// Detect deep nesting.

public class DeepNestingProblem {
    public void process(boolean a, boolean b, boolean c, boolean d) {
        if (a) {
            if (b) {
                if (c) {
                    if (d) {
                        System.out.println("Deeply nested code");
                    }
                }
            }
        }
    }
}
