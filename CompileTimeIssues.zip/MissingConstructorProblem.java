// Detect missing constructor.

public class MissingConstructorProblem {
    public static void main(String[] args) {
        new MissingConstructorProblem("parameter");
    }
}
