// Detect incompatible return type.

public class IncompatibleReturnTypeProblem {
    public String method() {
        return 10;
    }
}
