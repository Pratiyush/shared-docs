// Detect type mismatch.

public class TypeMismatchProblem {
    public void method() {
        int number = "ten";
    }
}
