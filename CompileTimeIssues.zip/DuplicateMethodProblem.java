// Detect duplicate method.

public class DuplicateMethodProblem {
    public void method() {
        System.out.println("First method");
    }

    public void method() {
        System.out.println("Duplicate method");
    }
}
