// Detect abstract class instantiation.

public abstract class AbstractClassInstantiationProblem {
}

public class Test {
    public void method() {
        AbstractClassInstantiationProblem obj = new AbstractClassInstantiationProblem();
    }
}
