// Detect non-static variable access from static context.

public class StaticVariableAccessProblem {
    private int number;

    public static void method() {
        System.out.println(number);
    }
}
