// Detect abstract method in concrete class.

public class AbstractMethodInConcreteClassProblem {
    public abstract void method();
}
