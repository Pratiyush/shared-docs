// Detect undefined variable.

public class UndefinedVariableProblem {
    public void method() {
        int result = x + 10;
    }
}
