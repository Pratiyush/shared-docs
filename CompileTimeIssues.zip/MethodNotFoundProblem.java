// Detect method not found.

public class MethodNotFoundProblem {
    public void method() {
        this.nonExistentMethod();
    }
}
