// Detect missing semicolon.

public class MissingSemicolonProblem {
    public void method() {
        System.out.println("Hello World")
    }
}
