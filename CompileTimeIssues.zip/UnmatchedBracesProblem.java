// Detect unmatched braces.

public class UnmatchedBracesProblem {
    public void method() {
        if (true) {
            System.out.println("Missing closing brace");
    }
}
