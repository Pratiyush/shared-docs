// Detect package not found.

import nonexistent.package.ClassName;

public class PackageNotFoundProblem {
    public void method() {
        ClassName obj = new ClassName();
    }
}
