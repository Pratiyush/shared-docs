// Detect interface method not implemented.

public class InterfaceMethodNotImplementedProblem implements Runnable {
}
