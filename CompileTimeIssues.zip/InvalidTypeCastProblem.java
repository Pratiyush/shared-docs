// Detect invalid type cast.

public class InvalidTypeCastProblem {
    public void method() {
        Object obj = new Integer(10);
        String str = (String) obj;
    }
}
