// Detect unclosed string literal.

public class UnclosedStringLiteralProblem {
    public void method() {
        String text = "Hello World;
    }
}
