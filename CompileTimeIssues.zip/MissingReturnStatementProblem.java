// Detect missing return statement.

public class MissingReturnStatementProblem {
    public String method() {
        // Missing return statement
    }
}
