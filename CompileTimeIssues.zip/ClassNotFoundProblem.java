// Detect class not found.

public class ClassNotFoundProblem {
    public void method() {
        NonExistentClass obj = new NonExistentClass();
    }
}
