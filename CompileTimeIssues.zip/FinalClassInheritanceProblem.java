// Detect final class inheritance.

public final class FinalClassInheritanceProblem {
}

public class SubClass extends FinalClassInheritanceProblem {
}
