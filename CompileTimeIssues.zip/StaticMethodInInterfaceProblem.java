// Detect static method in interface.

public interface StaticMethodInInterfaceProblem {
    public static void method() {
        System.out.println("Static method in interface");
    }
}
