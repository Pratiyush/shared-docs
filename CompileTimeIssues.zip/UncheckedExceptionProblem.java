// Detect unchecked exception.

public class UncheckedExceptionProblem {
    public void method() {
        throw new RuntimeException();
    }
}
