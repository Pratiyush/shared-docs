// Detect improper resource management.

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Problem06 {
    public void method() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("file.txt"));
        String line = br.readLine();
        System.out.println(line);
    }
}
