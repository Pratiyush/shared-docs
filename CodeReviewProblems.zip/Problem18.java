// Detect overly complex expressions.

public class Problem18 {
    public void method() {
        if ((a && b) || (c && d) || (e && f) || (g && h) || (i && j)) {
            System.out.println("Overly complex expression");
        }
    }
}
