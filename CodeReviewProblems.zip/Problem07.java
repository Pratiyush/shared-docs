// Detect magic numbers.

public class Problem07 {
    public void method() {
        for (int i = 0; i < 100; i++) {
            System.out.println(i);
        }
    }
}
