// Detect long methods.

public class Problem09 {
    public void method() {
        System.out.println("Step 1");
        System.out.println("Step 2");
        System.out.println("Step 3");
        System.out.println("Step 4");
        System.out.println("Step 5");
        System.out.println("Step 6");
        System.out.println("Step 7");
        System.out.println("Step 8");
        System.out.println("Step 9");
        System.out.println("Step 10");
    }
}
