// Detect improper logging.

public class Problem16 {
    public void method() {
        System.out.println("Log message");
    }
}
