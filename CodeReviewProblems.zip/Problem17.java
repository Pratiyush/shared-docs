// Detect missing synchronization in multi-threaded code.

public class Problem17 {
    private int counter = 0;

    public void method() {
        new Thread(() -> counter++).start();
        new Thread(() -> counter++).start();
    }
}
