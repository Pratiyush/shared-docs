// Detect hard-coded values.

public class Problem03 {
    public void method() {
        int maxRetries = 5;
        System.out.println("Max retries: " + maxRetries);
    }
}
