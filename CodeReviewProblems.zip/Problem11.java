// Detect missing 'default' case in switch statements.

public class Problem11 {
    public void method(int value) {
        switch (value) {
            case 1:
                System.out.println("One");
                break;
            case 2:
                System.out.println("Two");
                break;
        }
    }
}
