// Detect improper comparison.

public class Problem15 {
    public void method() {
        String a = "test";
        if (a == "test") {
            System.out.println("Improper comparison");
        }
    }
}
