// Detect missing null checks.

public class Problem04 {
    public void method(String input) {
        System.out.println(input.length());
    }
}
