// Detect missing 'this' keyword in instance variable access.

public class Problem19 {
    private int counter = 0;

    public void method(int counter) {
        counter = counter;
    }
}
