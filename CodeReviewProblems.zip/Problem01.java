// Detect improper exception handling.

public class Problem01 {
    public void method() {
        try {
            int a = 10 / 0;
        } catch (Exception e) {
            System.out.println("Error occurred");
        }
    }
}
