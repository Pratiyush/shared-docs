// Detect unused imports and variables.

import java.util.List;
import java.util.ArrayList;

public class Problem02 {
    public void method() {
        int unusedVariable = 10;
        System.out.println("Hello World");
    }
}
