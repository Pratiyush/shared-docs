// Detect missing access modifiers.

class Problem08 {
    void method() {
        System.out.println("Missing access modifier");
    }
}
