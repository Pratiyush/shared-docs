// Detect improper use of static.

public class Problem12 {
    public static void method() {
        System.out.println("Static method called");
    }
}
