// Detect deep nesting.

public class Problem10 {
    public void method(boolean a, boolean b, boolean c, boolean d) {
        if (a) {
            if (b) {
                if (c) {
                    if (d) {
                        System.out.println("Deep nesting");
                    }
                }
            }
        }
    }
}
