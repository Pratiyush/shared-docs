// Detect use of deprecated APIs.

public class Problem20 {
    public void method() {
        Thread thread = new Thread();
        thread.stop();
    }
}
