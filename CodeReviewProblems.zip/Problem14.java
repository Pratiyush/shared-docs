// Detect commented-out code.

public class Problem14 {
    public void method() {
        // System.out.println("This line is commented out");
        System.out.println("Hello World");
    }
}
