// Detect inefficient loops.

import java.util.List;

public class Problem05 {
    public void method(List<String> items) {
        for (int i = 0; i < items.size(); i++) {
            for (int j = 0; j < items.size(); j++) {
                if (items.get(i).equals(items.get(j))) {
                    System.out.println("Duplicate found");
                }
            }
        }
    }
}
